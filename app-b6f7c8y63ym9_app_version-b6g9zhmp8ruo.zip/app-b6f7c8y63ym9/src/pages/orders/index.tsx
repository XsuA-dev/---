import {useCallback, useEffect, useState} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {withRouteGuard} from '@/components/RouteGuard'
import {getPaymentOrders} from '@/db/api'
import type {PaymentOrder} from '@/db/types'

function Orders() {
  const {user} = useAuth()
  const [orders, setOrders] = useState<PaymentOrder[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = useCallback(async () => {
    if (!user) {
      setLoading(false)
      return
    }

    setLoading(true)
    const data = await getPaymentOrders(user.id, 50)
    setOrders(data)
    setLoading(false)
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
      pending: '待支付',
      paid: '已支付',
      cancelled: '已取消'
    }
    return statusMap[status] || status
  }

  const getStatusColor = (status: string) => {
    const colorMap: Record<string, string> = {
      pending: 'text-accent',
      paid: 'text-primary',
      cancelled: 'text-muted-foreground'
    }
    return colorMap[status] || 'text-foreground'
  }

  const getOrderTypeText = (type: string) => {
    const typeMap: Record<string, string> = {
      subscription: '订阅套餐',
      single_query: '单次查询'
    }
    return typeMap[type] || type
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-xl text-muted-foreground">加载中...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-primary px-6 py-8">
        <h1 className="text-3xl font-bold text-white mb-2">我的订单</h1>
        <p className="text-xl text-white opacity-90">查看订单记录</p>
      </div>

      <div className="px-6 py-6">
        {orders.length === 0 ? (
          <div className="bg-card rounded-lg p-8 shadow-card text-center">
            <div className="i-mdi-receipt-text-outline text-6xl text-muted-foreground mb-3" />
            <p className="text-xl text-foreground mb-2">暂无订单记录</p>
            <p className="text-base text-muted-foreground mb-6">购买订阅套餐开始使用</p>
            <button
              type="button"
              onClick={() => Taro.navigateTo({url: '/pages/subscription/index'})}
              className="px-8 py-3 bg-gradient-primary text-white text-xl rounded-lg flex items-center justify-center leading-none mx-auto">
              查看套餐
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((order) => (
              <div
                key={order.id}
                className="bg-card rounded-lg p-5 shadow-card">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-lg font-bold text-foreground">{order.product_name}</span>
                      <span className={`text-base ${getStatusColor(order.status)}`}>
                        {getStatusText(order.status)}
                      </span>
                    </div>
                    <p className="text-base text-muted-foreground">{getOrderTypeText(order.order_type)}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary">¥{order.amount}</div>
                  </div>
                </div>

                <div className="border-t border-border pt-3 space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">订单号</span>
                    <span className="text-foreground">{order.order_no}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">创建时间</span>
                    <span className="text-foreground">{new Date(order.created_at).toLocaleString('zh-CN')}</span>
                  </div>
                  {order.paid_at && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">支付时间</span>
                      <span className="text-foreground">{new Date(order.paid_at).toLocaleString('zh-CN')}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default withRouteGuard(Orders)
