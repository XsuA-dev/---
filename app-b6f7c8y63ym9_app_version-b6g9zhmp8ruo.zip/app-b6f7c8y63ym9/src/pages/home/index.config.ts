export default definePageConfig({
  navigationBarTitleText: '源瞳产地雷达',
  enableShareAppMessage: true,
  enableShareTimeline: true
})
