import {useCallback, useEffect, useState} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {getTodayQuota, getCurrentSubscription, createOrUpdateTodayQuota} from '@/db/api'
import type {DailyQuota, Subscription} from '@/db/types'

export default function Home() {
  const {user} = useAuth()
  const [quota, setQuota] = useState<DailyQuota | null>(null)
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [loading, setLoading] = useState(true)

  const loadData = useCallback(async () => {
    if (!user) {
      setLoading(false)
      return
    }

    setLoading(true)
    const [subData, quotaData] = await Promise.all([
      getCurrentSubscription(user.id),
      getTodayQuota(user.id)
    ])

    setSubscription(subData)

    if (!quotaData && subData) {
      const newQuota = await createOrUpdateTodayQuota(user.id, subData.daily_quota)
      setQuota(newQuota)
    } else {
      setQuota(quotaData)
    }

    setLoading(false)
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  const handleQueryMethod = (method: string) => {
    if (!user) {
      Taro.showToast({title: '请先登录', icon: 'none'})
      Taro.navigateTo({url: '/pages/login/index'})
      return
    }

    const remaining = (quota?.quota_limit || 0) - (quota?.used_count || 0)
    if (remaining <= 0) {
      Taro.showModal({
        title: '查询次数已用完',
        content: '今日免费查询次数已用完，请升级订阅或明日再试',
        confirmText: '升级订阅',
        success: (res) => {
          if (res.confirm) {
            Taro.switchTab({url: '/pages/profile/index'})
          }
        }
      })
      return
    }

    Taro.navigateTo({url: `/pages/query/index?method=${method}`})
  }

  const handleViewHistory = () => {
    if (!user) {
      Taro.showToast({title: '请先登录', icon: 'none'})
      Taro.navigateTo({url: '/pages/login/index'})
      return
    }
    Taro.switchTab({url: '/pages/history/index'})
  }

  const getSubscriptionName = (type: string) => {
    const names: Record<string, string> = {
      free: '免费版',
      personal: '个人版',
      professional: '专业版',
      enterprise: '企业版'
    }
    return names[type] || '免费版'
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-primary px-6 py-8">
        <h1 className="text-3xl font-bold text-white mb-2">源瞳产地雷达</h1>
        <p className="text-xl text-white opacity-90">从发货地到生产厂家的完整溯源</p>
      </div>

      <div className="px-6 py-6">
        {user && !loading && (
          <div className="bg-card rounded-lg p-5 mb-6 shadow-card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xl text-foreground">今日剩余查询次数</span>
              <span className="text-2xl font-bold text-primary">
                {(quota?.quota_limit || 0) - (quota?.used_count || 0)} / {quota?.quota_limit || 0}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-base text-muted-foreground">当前订阅</span>
              <span className="text-lg text-foreground">
                {getSubscriptionName(subscription?.subscription_type || 'free')}
              </span>
            </div>
          </div>
        )}

        {!user && !loading && (
          <div className="bg-card rounded-lg p-5 mb-6 shadow-card">
            <div className="text-center">
              <p className="text-xl text-foreground mb-3">登录后开始使用</p>
              <button
                type="button"
                onClick={() => Taro.navigateTo({url: '/pages/login/index'})}
                className="px-8 py-3 bg-gradient-primary text-white text-xl rounded-lg flex items-center justify-center leading-none mx-auto">
                立即登录
              </button>
            </div>
          </div>
        )}

        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-4">选择溯源方式</h2>
          <div className="space-y-3">
            <div
              onClick={() => handleQueryMethod('link')}
              className="bg-card rounded-lg p-5 shadow-card active:opacity-80 transition-opacity">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <div className="i-mdi-link text-3xl text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-foreground mb-1">粘贴商品链接</h3>
                  <p className="text-base text-muted-foreground">
                    支持1688、淘宝商品详情页链接
                  </p>
                </div>
                <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
              </div>
            </div>

            <div
              onClick={() => handleQueryMethod('ocr')}
              className="bg-card rounded-lg p-5 shadow-card active:opacity-80 transition-opacity">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <div className="i-mdi-camera text-3xl text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-foreground mb-1">拍照快递面单</h3>
                  <p className="text-base text-muted-foreground">自动识别寄件地址信息</p>
                </div>
                <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
              </div>
            </div>

            <div
              onClick={() => handleQueryMethod('manual')}
              className="bg-card rounded-lg p-5 shadow-card active:opacity-80 transition-opacity">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <div className="i-mdi-pencil text-3xl text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-foreground mb-1">手动输入发货地</h3>
                  <p className="text-base text-muted-foreground">直接填写已知发货地址</p>
                </div>
                <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-5 shadow-card">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-1">查询历史</h3>
              <p className="text-base text-muted-foreground">查看过往溯源记录</p>
            </div>
            <button
              type="button"
              onClick={handleViewHistory}
              className="px-6 py-3 bg-secondary text-secondary-foreground text-lg rounded-lg flex items-center justify-center leading-none">
              查看
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
