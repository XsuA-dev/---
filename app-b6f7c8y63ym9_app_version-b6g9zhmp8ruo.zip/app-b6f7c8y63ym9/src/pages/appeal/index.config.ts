export default definePageConfig({
  navigationBarTitleText: '反馈申诉',
  enableShareAppMessage: true,
  enableShareTimeline: true
})
