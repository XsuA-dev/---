import {useMemo, useState} from 'react'
import Taro, {getCurrentInstance} from '@tarojs/taro'
import {Image} from '@tarojs/components'
import {useAuth} from '@/contexts/AuthContext'
import {supabase} from '@/client/supabase'
import {selectMediaFiles, uploadToSupabase} from '@/utils/upload'
import {createAppeal} from '@/db/api'

export default function Appeal() {
  const {user} = useAuth()
  const queryId = useMemo(
    () => getCurrentInstance().router?.params?.queryId || '',
    []
  )

  const [reason, setReason] = useState('')
  const [files, setFiles] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const handleSelectFiles = async () => {
    try {
      const selectedFiles = await selectMediaFiles({count: 3, mediaType: ['image']})
      if (selectedFiles && selectedFiles.length > 0) {
        setFiles([...files, ...selectedFiles])
      }
    } catch (error) {
      console.error('选择文件失败:', error)
      Taro.showToast({title: '选择文件失败', icon: 'none'})
    }
  }

  const handleRemoveFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    if (!user) {
      Taro.showToast({title: '请先登录', icon: 'none'})
      return
    }

    if (!queryId) {
      Taro.showToast({title: '缺少查询记录ID', icon: 'none'})
      return
    }

    if (!reason.trim()) {
      Taro.showToast({title: '请填写申诉理由', icon: 'none'})
      return
    }

    setLoading(true)

    try {
      const uploadedFiles: string[] = []

      for (const file of files) {
        const uploadResult = await uploadToSupabase(file, {
          bucket: 'app-b6f7c8y63ym9_appeal_documents',
          userId: user.id
        })

        if (uploadResult.success && uploadResult.data) {
          const {data: urlData} = supabase.storage
            .from('app-b6f7c8y63ym9_appeal_documents')
            .getPublicUrl(uploadResult.data.path)
          uploadedFiles.push(urlData.publicUrl)
        }
      }

      const evidenceFiles = uploadedFiles.length > 0 ? {files: uploadedFiles} : null

      const appeal = await createAppeal(user.id, queryId, reason.trim(), evidenceFiles)

      if (!appeal) {
        throw new Error('创建申诉失败')
      }

      Taro.showToast({title: '申诉提交成功', icon: 'success'})
      setTimeout(() => {
        Taro.navigateBack()
      }, 1000)
    } catch (error: any) {
      console.error('提交申诉失败:', error)
      Taro.showToast({title: error.message || '提交失败', icon: 'none'})
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background px-6 py-6">
      <div className="bg-card rounded-lg p-6 shadow-card">
        <h2 className="text-2xl font-bold text-foreground mb-6">反馈申诉</h2>

        <div className="space-y-6">
          <div>
            <div className="text-lg text-foreground mb-2">
              申诉理由 <span className="text-accent">*</span>
            </div>
            <div className="border-2 border-input rounded-lg px-4 py-3 bg-background overflow-hidden">
              <textarea
                className="w-full text-xl text-foreground bg-transparent outline-none"
                placeholder="请详细说明申诉理由"
                rows={6}
                value={reason}
                onInput={(e) => {
                  const ev = e as any
                  setReason(ev.detail?.value ?? ev.target?.value ?? '')
                }}
              />
            </div>
          </div>

          <div>
            <div className="text-lg text-foreground mb-2">证明文件（选填）</div>
            <div className="space-y-3">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="relative">
                  <Image
                    src={'tempFilePath' in file ? file.tempFilePath : ''}
                    mode="aspectFit"
                    className="w-full h-48 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveFile(index)}
                    className="absolute top-2 right-2 w-8 h-8 bg-destructive rounded-full flex items-center justify-center">
                    <div className="i-mdi-close text-xl text-white" />
                  </button>
                </div>
              ))}

              {files.length < 3 && (
                <button
                  type="button"
                  onClick={handleSelectFiles}
                  className="w-full h-48 border-2 border-dashed border-input rounded-lg flex flex-col items-center justify-center gap-3 bg-background">
                  <div className="i-mdi-plus text-6xl text-muted-foreground" />
                  <span className="text-xl text-muted-foreground">
                    添加证明文件（最多3张）
                  </span>
                </button>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={handleSubmit}
            disabled={loading}
            className="w-full py-4 bg-gradient-primary text-white text-xl rounded-lg flex items-center justify-center leading-none disabled:opacity-50">
            {loading ? '提交中...' : '提交申诉'}
          </button>
        </div>
      </div>
    </div>
  )
}
