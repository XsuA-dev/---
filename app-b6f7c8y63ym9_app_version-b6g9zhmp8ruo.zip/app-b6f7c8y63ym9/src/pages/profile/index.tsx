import {useCallback, useEffect, useState} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {withRouteGuard} from '@/components/RouteGuard'
import {getCurrentSubscription, getTodayQuota} from '@/db/api'
import type {Subscription, DailyQuota} from '@/db/types'

function Profile() {
  const {user, profile, signOut} = useAuth()
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [quota, setQuota] = useState<DailyQuota | null>(null)
  const [loading, setLoading] = useState(true)

  const loadData = useCallback(async () => {
    if (!user) {
      setLoading(false)
      return
    }

    setLoading(true)
    const [subData, quotaData] = await Promise.all([
      getCurrentSubscription(user.id),
      getTodayQuota(user.id)
    ])

    setSubscription(subData)
    setQuota(quotaData)
    setLoading(false)
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  const handleSignOut = async () => {
    Taro.showModal({
      title: '确认退出',
      content: '确定要退出登录吗？',
      success: async (res) => {
        if (res.confirm) {
          await signOut()
          Taro.showToast({title: '已退出登录', icon: 'success'})
          Taro.reLaunch({url: '/pages/home/index'})
        }
      }
    })
  }

  const handleUpgrade = () => {
    Taro.navigateTo({url: '/pages/subscription/index'})
  }

  const getSubscriptionName = (type: string) => {
    const names: Record<string, string> = {
      free: '免费版',
      personal: '个人版',
      professional: '专业版',
      enterprise: '企业版'
    }
    return names[type] || '免费版'
  }

  const getSubscriptionDesc = (type: string) => {
    const descs: Record<string, string> = {
      free: '每日3次基础溯源',
      personal: '每日20次深度报告',
      professional: '每日100次深度报告+图谱展示',
      enterprise: 'API接口+批量溯源'
    }
    return descs[type] || '每日3次基础溯源'
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-primary px-6 py-8">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
            <div className="i-mdi-account text-4xl text-primary" />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white mb-1">
              {(profile?.username as string) || '用户'}
            </h1>
            <p className="text-lg text-white opacity-90">
              {profile?.role === 'admin' ? '管理员' : '普通用户'}
            </p>
          </div>
        </div>
      </div>

      <div className="px-6 py-6 space-y-4">
        <div className="bg-card rounded-lg p-5 shadow-card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-foreground">订阅管理</h2>
            {subscription?.subscription_type === 'free' && (
              <button
                type="button"
                onClick={handleUpgrade}
                className="px-4 py-2 bg-gradient-primary text-white text-base rounded-lg flex items-center justify-center leading-none">
                升级
              </button>
            )}
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-base text-muted-foreground">当前订阅</span>
              <span className="text-lg font-bold text-foreground">
                {getSubscriptionName(subscription?.subscription_type || 'free')}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-base text-muted-foreground">订阅状态</span>
              <span className="text-lg text-foreground">
                {subscription?.status === 'active' ? '有效' : '已过期'}
              </span>
            </div>
            {subscription?.end_date && (
              <div className="flex items-center justify-between">
                <span className="text-base text-muted-foreground">到期时间</span>
                <span className="text-lg text-foreground">
                  {new Date(subscription.end_date).toLocaleDateString('zh-CN')}
                </span>
              </div>
            )}
            <div className="flex items-center justify-between">
              <span className="text-base text-muted-foreground">今日剩余次数</span>
              <span className="text-lg font-bold text-primary">
                {(quota?.quota_limit || 0) - (quota?.used_count || 0)} / {quota?.quota_limit || 0}
              </span>
            </div>
            <div className="pt-3 border-t border-border">
              <p className="text-base text-muted-foreground">
                {getSubscriptionDesc(subscription?.subscription_type || 'free')}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg shadow-card overflow-hidden">
          <div
            onClick={() => Taro.navigateTo({url: '/pages/orders/index'})}
            className="flex items-center justify-between px-5 py-4 active:bg-muted transition-colors">
            <div className="flex items-center gap-3">
              <div className="i-mdi-receipt-text-outline text-2xl text-foreground" />
              <span className="text-lg text-foreground">我的订单</span>
            </div>
            <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
          </div>

          <div className="border-t border-border" />

          <div
            onClick={() => Taro.showToast({title: '功能开发中', icon: 'none'})}
            className="flex items-center justify-between px-5 py-4 active:bg-muted transition-colors">
            <div className="flex items-center gap-3">
              <div className="i-mdi-file-document-outline text-2xl text-foreground" />
              <span className="text-lg text-foreground">隐私条款</span>
            </div>
            <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
          </div>

          <div className="border-t border-border" />

          <div
            onClick={() => Taro.showToast({title: '功能开发中', icon: 'none'})}
            className="flex items-center justify-between px-5 py-4 active:bg-muted transition-colors">
            <div className="flex items-center gap-3">
              <div className="i-mdi-information-outline text-2xl text-foreground" />
              <span className="text-lg text-foreground">关于我们</span>
            </div>
            <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
          </div>

          <div className="border-t border-border" />

          <div
            onClick={() => Taro.showToast({title: '功能开发中', icon: 'none'})}
            className="flex items-center justify-between px-5 py-4 active:bg-muted transition-colors">
            <div className="flex items-center gap-3">
              <div className="i-mdi-headset text-2xl text-foreground" />
              <span className="text-lg text-foreground">联系客服</span>
            </div>
            <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
          </div>
        </div>

        <button
          type="button"
          onClick={handleSignOut}
          className="w-full py-4 bg-card text-accent text-xl rounded-lg shadow-card flex items-center justify-center leading-none">
          退出登录
        </button>
      </div>
    </div>
  )
}

export default withRouteGuard(Profile)
