export default definePageConfig({
  navigationBarTitleText: '查询历史',
  enableShareAppMessage: true,
  enableShareTimeline: true
})
