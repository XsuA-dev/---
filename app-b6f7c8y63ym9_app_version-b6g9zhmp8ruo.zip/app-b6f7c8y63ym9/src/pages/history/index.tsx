import {useCallback, useEffect, useState} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {withRouteGuard} from '@/components/RouteGuard'
import {getQueryRecords} from '@/db/api'
import type {QueryRecord} from '@/db/types'

function History() {
  const {user} = useAuth()
  const [records, setRecords] = useState<QueryRecord[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = useCallback(async () => {
    if (!user) {
      setLoading(false)
      return
    }

    setLoading(true)
    const data = await getQueryRecords(user.id, 50)
    setRecords(data)
    setLoading(false)
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  const handleViewReport = (recordId: string) => {
    Taro.navigateTo({url: `/pages/report/index?id=${recordId}`})
  }

  const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
      pending: '待处理',
      processing: '处理中',
      completed: '已完成',
      failed: '失败'
    }
    return statusMap[status] || status
  }

  const getStatusColor = (status: string) => {
    const colorMap: Record<string, string> = {
      pending: 'text-muted-foreground',
      processing: 'text-primary',
      completed: 'text-foreground',
      failed: 'text-accent'
    }
    return colorMap[status] || 'text-foreground'
  }

  const getMethodText = (method: string) => {
    const methodMap: Record<string, string> = {
      link: '链接解析',
      ocr: '面单OCR',
      manual: '手动输入'
    }
    return methodMap[method] || method
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-xl text-muted-foreground">加载中...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-primary px-6 py-8">
        <h1 className="text-3xl font-bold text-white mb-2">查询历史</h1>
        <p className="text-xl text-white opacity-90">查看过往溯源记录</p>
      </div>

      <div className="px-6 py-6">
        {records.length === 0 ? (
          <div className="bg-card rounded-lg p-8 shadow-card text-center">
            <div className="i-mdi-history text-6xl text-muted-foreground mb-3" />
            <p className="text-xl text-foreground mb-2">暂无查询记录</p>
            <p className="text-base text-muted-foreground mb-6">开始您的第一次溯源查询</p>
            <button
              type="button"
              onClick={() => Taro.switchTab({url: '/pages/home/index'})}
              className="px-8 py-3 bg-gradient-primary text-white text-xl rounded-lg flex items-center justify-center leading-none mx-auto">
              开始查询
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {records.map((record) => (
              <div
                key={record.id}
                onClick={() => handleViewReport(record.id)}
                className="bg-card rounded-lg p-5 shadow-card active:opacity-80 transition-opacity">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-lg font-bold text-foreground">
                        {getMethodText(record.input_method)}
                      </span>
                      <span className={`text-base ${getStatusColor(record.status)}`}>
                        {getStatusText(record.status)}
                      </span>
                    </div>
                    {record.shipping_address && (
                      <p className="text-base text-muted-foreground line-clamp-2">
                        {record.shipping_address}
                      </p>
                    )}
                    {record.province && (
                      <p className="text-base text-muted-foreground">
                        {record.province} {record.city} {record.district}
                      </p>
                    )}
                  </div>
                  <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
                </div>
                <div className="text-sm text-muted-foreground">
                  {new Date(record.created_at).toLocaleString('zh-CN')}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default withRouteGuard(History)
