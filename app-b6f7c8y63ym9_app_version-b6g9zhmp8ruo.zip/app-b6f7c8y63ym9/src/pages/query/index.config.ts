export default definePageConfig({
  navigationBarTitleText: '溯源查询',
  enableShareAppMessage: true,
  enableShareTimeline: true
})
