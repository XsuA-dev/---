import {useMemo, useState} from 'react'
import Taro, {getCurrentInstance} from '@tarojs/taro'
import {Image} from '@tarojs/components'
import {useAuth} from '@/contexts/AuthContext'
import {supabase} from '@/client/supabase'
import {selectMediaFiles, uploadToSupabase} from '@/utils/upload'
import {createQueryRecord, incrementQuotaUsage} from '@/db/api'

export default function Query() {
  const {user} = useAuth()
  const method = useMemo(
    () => getCurrentInstance().router?.params?.method || 'link',
    []
  )

  const [link, setLink] = useState('')
  const [address, setAddress] = useState('')
  const [imageFile, setImageFile] = useState<any>(null)
  const [imageUrl, setImageUrl] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSelectImage = async () => {
    try {
      const files = await selectMediaFiles({count: 1, mediaType: ['image']})
      if (files && files.length > 0) {
        const file = files[0]
        setImageFile(file)
        if ('tempFilePath' in file) {
          setImageUrl(file.tempFilePath)
        }
      }
    } catch (error) {
      console.error('选择图片失败:', error)
      Taro.showToast({title: '选择图片失败', icon: 'none'})
    }
  }

  const handleSubmit = async () => {
    if (!user) {
      Taro.showToast({title: '请先登录', icon: 'none'})
      return
    }

    let inputData: Record<string, any> = {}

    if (method === 'link') {
      if (!link.trim()) {
        Taro.showToast({title: '请输入商品链接', icon: 'none'})
        return
      }
      inputData = {link: link.trim()}
    } else if (method === 'ocr') {
      if (!imageFile) {
        Taro.showToast({title: '请选择快递面单图片', icon: 'none'})
        return
      }
    } else if (method === 'manual') {
      if (!address.trim()) {
        Taro.showToast({title: '请输入发货地址', icon: 'none'})
        return
      }
      inputData = {address: address.trim()}
    }

    setLoading(true)

    try {
      let uploadedImageUrl = ''
      if (method === 'ocr' && imageFile) {
        const uploadResult = await uploadToSupabase(imageFile, {
          bucket: 'app-b6f7c8y63ym9_waybill_images',
          userId: user.id
        })

        if (!uploadResult.success || !uploadResult.data) {
          throw new Error('图片上传失败')
        }

        const {data: urlData} = supabase.storage
          .from('app-b6f7c8y63ym9_waybill_images')
          .getPublicUrl(uploadResult.data.path)
        uploadedImageUrl = urlData.publicUrl
        inputData = {image_url: uploadedImageUrl}
      }

      const queryRecord = await createQueryRecord(user.id, method, inputData)
      if (!queryRecord) {
        throw new Error('创建查询记录失败')
      }

      await incrementQuotaUsage(user.id)

      Taro.showLoading({title: '溯源中...'})

      const {data, error} = await supabase.functions.invoke('trace_origin', {
        body: {
          query_id: queryRecord.id,
          method,
          input_data: inputData
        }
      })

      Taro.hideLoading()

      if (error) {
        const errorMsg = (await error?.context?.text?.()) || error.message
        throw new Error(errorMsg)
      }

      if (!data?.success) {
        throw new Error(data?.error || '溯源失败')
      }

      Taro.showToast({title: '溯源完成', icon: 'success'})
      setTimeout(() => {
        Taro.redirectTo({url: `/pages/report/index?id=${queryRecord.id}`})
      }, 500)
    } catch (error: any) {
      console.error('溯源失败:', error)
      Taro.showToast({title: error.message || '溯源失败', icon: 'none'})
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background px-6 py-6">
      <div className="bg-card rounded-lg p-6 shadow-card">
        <h2 className="text-2xl font-bold text-foreground mb-6">
          {method === 'link' && '粘贴商品链接'}
          {method === 'ocr' && '拍照快递面单'}
          {method === 'manual' && '手动输入发货地'}
        </h2>

        {method === 'link' && (
          <div className="space-y-4">
            <div>
              <div className="text-lg text-foreground mb-2">商品链接</div>
              <div className="border-2 border-input rounded-lg px-4 py-3 bg-background overflow-hidden">
                <textarea
                  className="w-full text-xl text-foreground bg-transparent outline-none"
                  placeholder="请粘贴1688或淘宝商品详情页链接"
                  rows={4}
                  value={link}
                  onInput={(e) => {
                    const ev = e as any
                    setLink(ev.detail?.value ?? ev.target?.value ?? '')
                  }}
                />
              </div>
            </div>
          </div>
        )}

        {method === 'ocr' && (
          <div className="space-y-4">
            <div>
              <div className="text-lg text-foreground mb-2">快递面单图片</div>
              {imageUrl ? (
                <div className="relative">
                  <Image
                    src={imageUrl}
                    mode="aspectFit"
                    className="w-full h-80 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={handleSelectImage}
                    className="mt-3 w-full py-3 bg-secondary text-secondary-foreground text-xl rounded-lg flex items-center justify-center leading-none">
                    重新选择
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleSelectImage}
                  className="w-full h-80 border-2 border-dashed border-input rounded-lg flex flex-col items-center justify-center gap-3 bg-background">
                  <div className="i-mdi-camera text-6xl text-muted-foreground" />
                  <span className="text-xl text-muted-foreground">点击选择图片</span>
                </button>
              )}
            </div>
          </div>
        )}

        {method === 'manual' && (
          <div className="space-y-4">
            <div>
              <div className="text-lg text-foreground mb-2">发货地址</div>
              <div className="border-2 border-input rounded-lg px-4 py-3 bg-background overflow-hidden">
                <textarea
                  className="w-full text-xl text-foreground bg-transparent outline-none"
                  placeholder="请输入发货地址，如：浙江省杭州市萧山区"
                  rows={4}
                  value={address}
                  onInput={(e) => {
                    const ev = e as any
                    setAddress(ev.detail?.value ?? ev.target?.value ?? '')
                  }}
                />
              </div>
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={handleSubmit}
          disabled={loading}
          className="w-full mt-6 py-4 bg-gradient-primary text-white text-xl rounded-lg flex items-center justify-center leading-none disabled:opacity-50">
          {loading ? '处理中...' : '开始溯源'}
        </button>
      </div>
    </div>
  )
}
