import {useState} from 'react'
import Taro, {getEnv} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {supabase} from '@/client/supabase'
import {withRouteGuard} from '@/components/RouteGuard'

interface SubscriptionPlan {
  type: 'personal' | 'professional' | 'enterprise'
  name: string
  price: number
  duration: number
  dailyQuota: number
  features: string[]
}

const plans: SubscriptionPlan[] = [
  {
    type: 'personal',
    name: '个人版',
    price: 29.9,
    duration: 30,
    dailyQuota: 20,
    features: ['每日20次深度溯源', '完整溯源报告', '历史记录查询', '7x24小时客服']
  },
  {
    type: 'professional',
    name: '专业版',
    price: 99.9,
    duration: 30,
    dailyQuota: 100,
    features: ['每日100次深度溯源', '企业关联图谱', '数据导出功能', '优先客服支持', 'API接口调用']
  },
  {
    type: 'enterprise',
    name: '企业版',
    price: 299.9,
    duration: 30,
    dailyQuota: 500,
    features: ['每日500次深度溯源', '批量溯源功能', '定制化报告', '专属客户经理', '私有化部署支持']
  }
]

function Subscription() {
  const {user, profile} = useAuth()
  const [loading, setLoading] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null)

  const handleSelectPlan = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan)
  }

  const handlePurchase = async () => {
    if (!selectedPlan) {
      Taro.showToast({title: '请选择套餐', icon: 'none'})
      return
    }

    if (!user) {
      Taro.showToast({title: '请先登录', icon: 'none'})
      return
    }

    const isWeApp = getEnv() === 'WEAPP'
    if (!isWeApp) {
      Taro.showToast({title: '非微信小程序环境无法发起支付，请在正式版微信小程序中使用此功能', icon: 'none', duration: 3000})
      return
    }

    setLoading(true)

    try {
      let openid = profile?.openid

      if (!openid) {
        const {code} = await Taro.login()
        const {data: openidData, error: openidError} = await supabase.functions.invoke('get_wechat_openid', {
          body: {code}
        })

        if (openidError || !openidData?.success) {
          throw new Error('获取openid失败')
        }

        openid = openidData.openid

        await supabase.from('profiles').update({openid}).eq('id', user.id)
      }

      const {data: paymentData, error: paymentError} = await supabase.functions.invoke('create_wechat_payment', {
        body: {
          user_id: user.id,
          openid,
          order_type: 'subscription',
          product_name: `${selectedPlan.name}订阅（${selectedPlan.duration}天）`,
          amount: selectedPlan.price,
          subscription_type: selectedPlan.type,
          subscription_duration_days: selectedPlan.duration
        }
      })

      if (paymentError) {
        const errorMsg = await paymentError?.context?.text?.()
        throw new Error(errorMsg || '创建支付失败')
      }

      if (!paymentData?.success) {
        throw new Error(paymentData?.error || '创建支付失败')
      }

      const {payment_params, order_id} = paymentData

      await Taro.requestPayment({
        timeStamp: payment_params.timeStamp,
        nonceStr: payment_params.nonceStr,
        package: payment_params.package,
        signType: payment_params.signType,
        paySign: payment_params.paySign
      })

      Taro.showToast({title: '支付成功', icon: 'success'})
      setTimeout(() => {
        Taro.navigateTo({url: `/pages/orders/index?order_id=${order_id}`})
      }, 1000)
    } catch (error: any) {
      console.error('支付失败:', error)
      if (error.errMsg && error.errMsg.includes('cancel')) {
        Taro.showToast({title: '支付已取消', icon: 'none'})
      } else {
        Taro.showToast({title: error.message || '支付失败', icon: 'none'})
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-primary px-6 py-8">
        <h1 className="text-3xl font-bold text-white mb-2">订阅套餐</h1>
        <p className="text-xl text-white opacity-90">选择适合您的套餐</p>
      </div>

      <div className="px-6 py-6 space-y-4">
        {plans.map((plan) => (
          <div
            key={plan.type}
            onClick={() => handleSelectPlan(plan)}
            className={`bg-card rounded-lg p-6 shadow-card transition-all ${
              selectedPlan?.type === plan.type ? 'border-2 border-primary' : 'border-2 border-transparent'
            }`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h2>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-primary">¥{plan.price}</span>
                  <span className="text-lg text-muted-foreground">/{plan.duration}天</span>
                </div>
              </div>
              <div
                className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  selectedPlan?.type === plan.type ? 'border-primary bg-primary' : 'border-border'
                }`}>
                {selectedPlan?.type === plan.type && <div className="i-mdi-check text-lg text-white" />}
              </div>
            </div>

            <div className="space-y-2">
              {plan.features.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2">
                  <div className="i-mdi-check-circle text-xl text-primary" />
                  <span className="text-lg text-foreground">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        ))}

        <button
          type="button"
          onClick={handlePurchase}
          disabled={!selectedPlan || loading}
          className="w-full py-4 bg-gradient-primary text-white text-xl rounded-lg flex items-center justify-center leading-none disabled:opacity-50">
          {loading ? '处理中...' : selectedPlan ? `立即购买 ¥${selectedPlan.price}` : '请选择套餐'}
        </button>
      </div>
    </div>
  )
}

export default withRouteGuard(Subscription)
