export default definePageConfig({
  navigationBarTitleText: '订阅套餐',
  enableShareAppMessage: true,
  enableShareTimeline: true
})
