import {useCallback, useEffect, useMemo, useState} from 'react'
import Taro, {getCurrentInstance, useDidShow, useShareAppMessage, useShareTimeline} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {getQueryRecordById, getManufacturersByQueryId} from '@/db/api'
import type {QueryRecord, Manufacturer} from '@/db/types'

export default function Report() {
  const {user} = useAuth()
  const queryId = useMemo(
    () => getCurrentInstance().router?.params?.id || '',
    []
  )

  const [record, setRecord] = useState<QueryRecord | null>(null)
  const [manufacturers, setManufacturers] = useState<Manufacturer[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = useCallback(async () => {
    if (!queryId) {
      setLoading(false)
      return
    }

    setLoading(true)
    const [recordData, manufacturersData] = await Promise.all([
      getQueryRecordById(queryId),
      getManufacturersByQueryId(queryId)
    ])

    setRecord(recordData)
    setManufacturers(manufacturersData)
    setLoading(false)
  }, [queryId])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  useShareAppMessage(() => ({
    title: '源瞳产地雷达 - 溯源报告',
    path: `/pages/report/index?id=${queryId}`
  }))

  useShareTimeline(() => ({
    title: '源瞳产地雷达 - 溯源报告'
  }))

  const handleAppeal = () => {
    if (!user) {
      Taro.showToast({title: '请先登录', icon: 'none'})
      return
    }
    Taro.navigateTo({url: `/pages/appeal/index?queryId=${queryId}`})
  }

  const getRiskColor = (flags: any) => {
    if (!flags || Object.keys(flags).length === 0) return 'text-foreground'
    return 'text-accent'
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-xl text-muted-foreground">加载中...</div>
      </div>
    )
  }

  if (!record) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-xl text-muted-foreground">未找到溯源记录</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-6">
      <div className="bg-gradient-primary px-6 py-8">
        <h1 className="text-2xl font-bold text-white mb-2">溯源报告</h1>
        <p className="text-lg text-white opacity-90">
          {record.status === 'completed' ? '溯源完成' : '处理中...'}
        </p>
      </div>

      <div className="px-6 py-6 space-y-4">
        <div className="bg-card rounded-lg p-5 shadow-card">
          <h2 className="text-xl font-bold text-foreground mb-4">发货地信息</h2>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-base text-muted-foreground">省份</span>
              <span className="text-lg text-foreground">{record.province || '-'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-base text-muted-foreground">城市</span>
              <span className="text-lg text-foreground">{record.city || '-'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-base text-muted-foreground">区县</span>
              <span className="text-lg text-foreground">{record.district || '-'}</span>
            </div>
            {record.shipping_address && (
              <div className="mt-3 pt-3 border-t border-border">
                <span className="text-base text-muted-foreground block mb-1">完整地址</span>
                <span className="text-lg text-foreground">{record.shipping_address}</span>
              </div>
            )}
          </div>
        </div>

        {manufacturers.length > 0 && (
          <div className="bg-card rounded-lg p-5 shadow-card">
            <h2 className="text-xl font-bold text-foreground mb-4">可能的生产厂家</h2>
            <div className="space-y-4">
              {manufacturers.map((mfr, index) => (
                <div
                  key={mfr.id}
                  className="border-2 border-border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-lg font-bold text-foreground">{mfr.name}</span>
                        {index === 0 && (
                          <span className="px-2 py-1 bg-primary text-primary-foreground text-sm rounded">
                            最可能
                          </span>
                        )}
                      </div>
                      {mfr.address && (
                        <p className="text-base text-muted-foreground">{mfr.address}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">
                        {mfr.confidence_score?.toFixed(0) || 0}%
                      </div>
                      <div className="text-sm text-muted-foreground">置信度</div>
                    </div>
                  </div>

                  {mfr.business_scope && (
                    <div className="mb-3">
                      <span className="text-base text-muted-foreground block mb-1">经营范围</span>
                      <p className="text-base text-foreground">{mfr.business_scope}</p>
                    </div>
                  )}

                  {mfr.reasoning && (
                    <div className="mb-3">
                      <span className="text-base text-muted-foreground block mb-1">推理依据</span>
                      <p className="text-base text-foreground">{mfr.reasoning}</p>
                    </div>
                  )}

                  {mfr.risk_flags && Object.keys(mfr.risk_flags).length > 0 && (
                    <div className="mt-3 pt-3 border-t border-border">
                      <div className="flex items-center gap-2">
                        <div className="i-mdi-alert text-xl text-accent" />
                        <span className={`text-base font-bold ${getRiskColor(mfr.risk_flags)}`}>
                          风险提示
                        </span>
                      </div>
                      <div className="mt-2 space-y-1">
                        {Object.entries(mfr.risk_flags).map(([key, value]) => (
                          <div
                            key={key}
                            className="text-base text-accent">
                            • {String(value)}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {manufacturers.length === 0 && record.status === 'completed' && (
          <div className="bg-card rounded-lg p-5 shadow-card text-center">
            <div className="i-mdi-information-outline text-6xl text-muted-foreground mb-3" />
            <p className="text-xl text-foreground mb-2">暂无匹配的生产厂家</p>
            <p className="text-base text-muted-foreground">
              该地区暂无相关生产企业数据
            </p>
          </div>
        )}

        <div className="flex gap-3">
          <button
            type="button"
            onClick={handleAppeal}
            className="flex-1 py-4 bg-secondary text-secondary-foreground text-xl rounded-lg flex items-center justify-center leading-none">
            申诉反馈
          </button>
          <button
            type="button"
            onClick={() => Taro.showToast({title: '分享功能开发中', icon: 'none'})}
            className="flex-1 py-4 bg-gradient-primary text-white text-xl rounded-lg flex items-center justify-center leading-none">
            分享报告
          </button>
        </div>
      </div>
    </div>
  )
}
