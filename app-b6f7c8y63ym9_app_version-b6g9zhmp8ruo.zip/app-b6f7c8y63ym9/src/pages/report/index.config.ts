export default definePageConfig({
  navigationBarTitleText: '溯源报告',
  enableShareAppMessage: true,
  enableShareTimeline: true
})
