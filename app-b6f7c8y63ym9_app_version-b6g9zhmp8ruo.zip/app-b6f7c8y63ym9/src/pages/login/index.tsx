import {useState} from 'react'
import Taro from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {STORAGE_KEY_REDIRECT_PATH} from '@/components/RouteGuard'

export default function Login() {
  const {signInWithUsername, signUpWithUsername, signInWithWechat} = useAuth()
  const [isLogin, setIsLogin] = useState(true)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [agreed, setAgreed] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async () => {
    if (!username.trim() || !password.trim()) {
      Taro.showToast({title: '请输入用户名和密码', icon: 'none'})
      return
    }

    if (!isLogin && !agreed) {
      Taro.showToast({title: '请阅读并同意用户协议', icon: 'none'})
      return
    }

    setLoading(true)
    const {error} = isLogin
      ? await signInWithUsername(username, password)
      : await signUpWithUsername(username, password)

    setLoading(false)

    if (error) {
      Taro.showToast({
        title: error.message || (isLogin ? '登录失败' : '注册失败'),
        icon: 'none'
      })
      return
    }

    Taro.showToast({title: isLogin ? '登录成功' : '注册成功', icon: 'success'})
    handleRedirect()
  }

  const handleWechatLogin = async () => {
    if (!agreed) {
      Taro.showToast({title: '请阅读并同意用户协议', icon: 'none'})
      return
    }

    setLoading(true)
    const {error} = await signInWithWechat()
    setLoading(false)

    if (error) {
      Taro.showToast({title: error.message || '微信登录失败', icon: 'none'})
      return
    }

    Taro.showToast({title: '登录成功', icon: 'success'})
    handleRedirect()
  }

  const handleRedirect = () => {
    const redirectPath = Taro.getStorageSync(STORAGE_KEY_REDIRECT_PATH)
    Taro.removeStorageSync(STORAGE_KEY_REDIRECT_PATH)

    if (redirectPath) {
      const normalizedPath = redirectPath.startsWith('/') ? redirectPath : `/${redirectPath}`
      const tabBarPages = ['/pages/home/index', '/pages/history/index', '/pages/profile/index']
      const isTabBar = tabBarPages.some((path) => normalizedPath.includes(path))

      if (isTabBar) {
        Taro.switchTab({url: normalizedPath})
      } else {
        Taro.navigateTo({url: normalizedPath})
      }
    } else {
      Taro.switchTab({url: '/pages/home/index'})
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="flex-1 flex flex-col px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold gradient-text mb-3">源瞳产地雷达</h1>
          <p className="text-xl text-muted-foreground">从发货地到生产厂家的完整溯源</p>
        </div>

        <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
          <div className="bg-card rounded-lg p-6 shadow-card">
            <div className="flex gap-2 mb-6">
              <button
                type="button"
                onClick={() => setIsLogin(true)}
                className={`flex-1 py-3 text-xl rounded-lg transition-colors ${
                  isLogin
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground'
                }`}>
                登录
              </button>
              <button
                type="button"
                onClick={() => setIsLogin(false)}
                className={`flex-1 py-3 text-xl rounded-lg transition-colors ${
                  !isLogin
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground'
                }`}>
                注册
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <div className="border-2 border-input rounded-lg px-4 py-3 bg-background overflow-hidden">
                  <input
                    className="w-full text-xl text-foreground bg-transparent outline-none"
                    placeholder="用户名"
                    value={username}
                    onInput={(e) => {
                      const ev = e as any
                      setUsername(ev.detail?.value ?? ev.target?.value ?? '')
                    }}
                  />
                </div>
              </div>

              <div>
                <div className="border-2 border-input rounded-lg px-4 py-3 bg-background overflow-hidden">
                  <input
                    className="w-full text-xl text-foreground bg-transparent outline-none"
                    type="password"
                    placeholder="密码"
                    value={password}
                    onInput={(e) => {
                      const ev = e as any
                      setPassword(ev.detail?.value ?? ev.target?.value ?? '')
                    }}
                  />
                </div>
              </div>

              {!isLogin && (
                <div
                  className="flex items-center gap-2"
                  onClick={() => setAgreed(!agreed)}>
                  <div
                    className={`w-5 h-5 border-2 rounded flex items-center justify-center ${
                      agreed ? 'bg-primary border-primary' : 'border-border'
                    }`}>
                    {agreed && <div className="i-mdi-check text-xl text-white" />}
                  </div>
                  <span className="text-base text-muted-foreground">
                    我已阅读并同意《用户协议》和《隐私政策》
                  </span>
                </div>
              )}

              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading}
                className="w-full py-4 bg-gradient-primary text-primary-foreground text-xl rounded-lg flex items-center justify-center leading-none disabled:opacity-50">
                {loading ? '处理中...' : isLogin ? '登录' : '注册'}
              </button>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-base">
                  <span className="bg-card px-4 text-muted-foreground">或</span>
                </div>
              </div>

              {!isLogin && (
                <div
                  className="flex items-center gap-2 mb-4"
                  onClick={() => setAgreed(!agreed)}>
                  <div
                    className={`w-5 h-5 border-2 rounded flex items-center justify-center ${
                      agreed ? 'bg-primary border-primary' : 'border-border'
                    }`}>
                    {agreed && <div className="i-mdi-check text-xl text-white" />}
                  </div>
                  <span className="text-base text-muted-foreground">
                    我已阅读并同意《用户协议》和《隐私政策》
                  </span>
                </div>
              )}

              <button
                type="button"
                onClick={handleWechatLogin}
                disabled={loading}
                className="w-full py-4 bg-card border-2 border-border text-foreground text-xl rounded-lg flex items-center justify-center gap-2 leading-none disabled:opacity-50">
                <div className="i-mdi-wechat text-2xl text-green-500" />
                微信登录
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
