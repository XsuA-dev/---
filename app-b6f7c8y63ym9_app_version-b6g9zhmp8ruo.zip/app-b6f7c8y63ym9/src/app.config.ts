const pages = [
  'pages/home/index',
  'pages/history/index',
  'pages/profile/index',
  'pages/login/index',
  'pages/query/index',
  'pages/report/index',
  'pages/appeal/index',
  'pages/subscription/index',
  'pages/orders/index'
]

export default defineAppConfig({
  pages,
  tabBar: {
    color: '#8C8C8C',
    selectedColor: '#1D39C4',
    backgroundColor: '#FFFFFF',
    borderStyle: 'white',
    list: [
      {
        pagePath: 'pages/home/index',
        text: '首页',
        iconPath: './assets/icons/home_unselected.png',
        selectedIconPath: './assets/icons/home_selected.png'
      },
      {
        pagePath: 'pages/history/index',
        text: '历史',
        iconPath: './assets/icons/history_unselected.png',
        selectedIconPath: './assets/icons/history_selected.png'
      },
      {
        pagePath: 'pages/profile/index',
        text: '我的',
        iconPath: './assets/icons/profile_unselected.png',
        selectedIconPath: './assets/icons/profile_selected.png'
      }
    ]
  },
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#FFFFFF',
    navigationBarTitleText: '源瞳产地雷达',
    navigationBarTextStyle: 'black'
  },
  permission: {
    'scope.camera': {
      desc: '用于拍摄快递面单进行OCR识别'
    },
    'scope.writePhotosAlbum': {
      desc: '用于保存溯源报告图片'
    }
  }
})
