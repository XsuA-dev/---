export type UserRole = 'user' | 'admin'

export type SubscriptionType = 'free' | 'personal' | 'professional' | 'enterprise'

export type SubscriptionStatus = 'active' | 'expired' | 'cancelled'

export type QueryStatus = 'pending' | 'processing' | 'completed' | 'failed'

export type AppealStatus = 'pending' | 'approved' | 'rejected'

export type OrderStatus = 'pending' | 'paid' | 'cancelled'

export type OrderType = 'subscription' | 'single_query'

export interface Profile {
  id: string
  username: string | null
  email: string | null
  phone: string | null
  role: UserRole
  openid: string | null
  created_at: string
  updated_at: string
}

export interface Subscription {
  id: string
  user_id: string
  subscription_type: SubscriptionType
  status: SubscriptionStatus
  start_date: string
  end_date: string | null
  daily_quota: number
  created_at: string
  updated_at: string
}

export interface DailyQuota {
  id: string
  user_id: string
  date: string
  used_count: number
  quota_limit: number
  created_at: string
  updated_at: string
}

export interface QueryRecord {
  id: string
  user_id: string
  input_method: string
  input_data: Record<string, any>
  shipping_address: string | null
  province: string | null
  city: string | null
  district: string | null
  status: QueryStatus
  result: Record<string, any> | null
  created_at: string
  updated_at: string
}

export interface Manufacturer {
  id: string
  query_id: string
  name: string
  address: string | null
  confidence_score: number | null
  reasoning: string | null
  risk_flags: Record<string, any> | null
  business_scope: string | null
  created_at: string
}

export interface Appeal {
  id: string
  query_id: string
  user_id: string
  reason: string
  evidence_files: Record<string, any> | null
  status: AppealStatus
  admin_response: string | null
  created_at: string
  updated_at: string
}

export interface PaymentOrder {
  id: string
  order_no: string
  user_id: string
  openid: string
  order_type: OrderType
  product_name: string
  amount: number
  status: OrderStatus
  subscription_type: SubscriptionType | null
  subscription_duration_days: number | null
  wechat_transaction_id: string | null
  paid_at: string | null
  created_at: string
  updated_at: string
}
