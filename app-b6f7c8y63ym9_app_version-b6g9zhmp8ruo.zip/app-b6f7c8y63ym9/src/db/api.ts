import {supabase} from '@/client/supabase'
import type {
  Profile,
  Subscription,
  DailyQuota,
  QueryRecord,
  Manufacturer,
  Appeal,
  PaymentOrder,
  QueryStatus,
  AppealStatus
} from './types'

// Profile相关
export async function getProfile(userId: string): Promise<Profile | null> {
  const {data, error} = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle()

  if (error) {
    console.error('获取用户资料失败:', error)
    return null
  }
  return data
}

export async function updateProfile(
  userId: string,
  updates: Partial<Profile>
): Promise<{success: boolean; error?: string}> {
  const {error} = await supabase.from('profiles').update(updates).eq('id', userId)

  if (error) {
    console.error('更新用户资料失败:', error)
    return {success: false, error: error.message}
  }
  return {success: true}
}

// Subscription相关
export async function getCurrentSubscription(userId: string): Promise<Subscription | null> {
  const {data, error} = await supabase
    .from('subscriptions')
    .select('*')
    .eq('user_id', userId)
    .eq('status', 'active')
    .order('created_at', {ascending: false})
    .limit(1)
    .maybeSingle()

  if (error) {
    console.error('获取订阅信息失败:', error)
    return null
  }
  return data
}

// Daily Quota相关
export async function getTodayQuota(userId: string): Promise<DailyQuota | null> {
  const today = new Date().toISOString().split('T')[0]

  const {data, error} = await supabase
    .from('daily_quotas')
    .select('*')
    .eq('user_id', userId)
    .eq('date', today)
    .maybeSingle()

  if (error) {
    console.error('获取今日配额失败:', error)
    return null
  }
  return data
}

export async function createOrUpdateTodayQuota(
  userId: string,
  quotaLimit: number
): Promise<DailyQuota | null> {
  const today = new Date().toISOString().split('T')[0]

  const {data: existing} = await supabase
    .from('daily_quotas')
    .select('*')
    .eq('user_id', userId)
    .eq('date', today)
    .maybeSingle()

  if (existing) {
    return existing
  }

  const {data, error} = await supabase
    .from('daily_quotas')
    .insert({
      user_id: userId,
      date: today,
      used_count: 0,
      quota_limit: quotaLimit
    })
    .select()
    .maybeSingle()

  if (error) {
    console.error('创建今日配额失败:', error)
    return null
  }
  return data
}

export async function incrementQuotaUsage(userId: string): Promise<{success: boolean}> {
  const today = new Date().toISOString().split('T')[0]

  const {error} = await supabase.rpc('increment_quota_usage', {
    p_user_id: userId,
    p_date: today
  })

  if (error) {
    console.error('增加配额使用失败:', error)
    return {success: false}
  }
  return {success: true}
}

// Query Record相关
export async function createQueryRecord(
  userId: string,
  inputMethod: string,
  inputData: Record<string, any>
): Promise<QueryRecord | null> {
  const {data, error} = await supabase
    .from('query_records')
    .insert({
      user_id: userId,
      input_method: inputMethod,
      input_data: inputData,
      status: 'pending'
    })
    .select()
    .maybeSingle()

  if (error) {
    console.error('创建查询记录失败:', error)
    return null
  }
  return data
}

export async function updateQueryRecord(
  queryId: string,
  updates: Partial<QueryRecord>
): Promise<{success: boolean}> {
  const {error} = await supabase.from('query_records').update(updates).eq('id', queryId)

  if (error) {
    console.error('更新查询记录失败:', error)
    return {success: false}
  }
  return {success: true}
}

export async function getQueryRecords(
  userId: string,
  limit = 20,
  offset = 0
): Promise<QueryRecord[]> {
  const {data, error} = await supabase
    .from('query_records')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', {ascending: false})
    .range(offset, offset + limit - 1)

  if (error) {
    console.error('获取查询记录失败:', error)
    return []
  }
  return Array.isArray(data) ? data : []
}

export async function getQueryRecordById(queryId: string): Promise<QueryRecord | null> {
  const {data, error} = await supabase
    .from('query_records')
    .select('*')
    .eq('id', queryId)
    .maybeSingle()

  if (error) {
    console.error('获取查询记录详情失败:', error)
    return null
  }
  return data
}

// Manufacturer相关
export async function getManufacturersByQueryId(queryId: string): Promise<Manufacturer[]> {
  const {data, error} = await supabase
    .from('manufacturers')
    .select('*')
    .eq('query_id', queryId)
    .order('confidence_score', {ascending: false})

  if (error) {
    console.error('获取厂家信息失败:', error)
    return []
  }
  return Array.isArray(data) ? data : []
}

// Appeal相关
export async function createAppeal(
  userId: string,
  queryId: string,
  reason: string,
  evidenceFiles: Record<string, any> | null
): Promise<Appeal | null> {
  const {data, error} = await supabase
    .from('appeals')
    .insert({
      user_id: userId,
      query_id: queryId,
      reason,
      evidence_files: evidenceFiles,
      status: 'pending'
    })
    .select()
    .maybeSingle()

  if (error) {
    console.error('创建申诉失败:', error)
    return null
  }
  return data
}

export async function getAppealsByUserId(userId: string): Promise<Appeal[]> {
  const {data, error} = await supabase
    .from('appeals')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', {ascending: false})

  if (error) {
    console.error('获取申诉列表失败:', error)
    return []
  }
  return Array.isArray(data) ? data : []
}

export async function getAllAppeals(): Promise<Appeal[]> {
  const {data, error} = await supabase
    .from('appeals')
    .select('*')
    .order('created_at', {ascending: false})

  if (error) {
    console.error('获取所有申诉失败:', error)
    return []
  }
  return Array.isArray(data) ? data : []
}

// PaymentOrder相关
export async function getPaymentOrders(userId: string, limit = 20, offset = 0): Promise<PaymentOrder[]> {
  const {data, error} = await supabase
    .from('payment_orders')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', {ascending: false})
    .range(offset, offset + limit - 1)

  if (error) {
    console.error('获取订单列表失败:', error)
    return []
  }
  return Array.isArray(data) ? data : []
}

export async function getPaymentOrderById(orderId: string): Promise<PaymentOrder | null> {
  const {data, error} = await supabase.from('payment_orders').select('*').eq('id', orderId).maybeSingle()

  if (error) {
    console.error('获取订单详情失败:', error)
    return null
  }
  return data
}

export async function getPaymentOrderByOrderNo(orderNo: string): Promise<PaymentOrder | null> {
  const {data, error} = await supabase.from('payment_orders').select('*').eq('order_no', orderNo).maybeSingle()

  if (error) {
    console.error('获取订单详情失败:', error)
    return null
  }
  return data
}
