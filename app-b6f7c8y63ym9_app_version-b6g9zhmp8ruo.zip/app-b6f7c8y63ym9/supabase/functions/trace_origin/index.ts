import {createClient} from 'jsr:@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

Deno.serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
  }

  if (req.method === 'OPTIONS') {
    return new Response('ok', {headers: corsHeaders})
  }

  try {
    const {query_id, method, input_data} = await req.json()

    if (!query_id) {
      return new Response(JSON.stringify({success: false, error: '缺少query_id'}), {
        status: 400,
        headers: {...corsHeaders, 'Content-Type': 'application/json'}
      })
    }

    await supabase.from('query_records').update({status: 'processing'}).eq('id', query_id)

    let shippingAddress = ''
    let province = ''
    let city = ''
    let district = ''

    if (method === 'link') {
      const parseResult = await parseProductLink(input_data.link)
      shippingAddress = parseResult.shipping_address || ''
      province = parseResult.province || ''
      city = parseResult.city || ''
      district = parseResult.district || ''
    } else if (method === 'ocr') {
      const ocrResult = await performOCR(input_data.image_url)
      shippingAddress = ocrResult.address || ''
      province = ocrResult.province || ''
      city = ocrResult.city || ''
      district = ocrResult.district || ''
    } else if (method === 'manual') {
      shippingAddress = input_data.address || ''
      const parsed = parseAddress(shippingAddress)
      province = parsed.province
      city = parsed.city
      district = parsed.district
    }

    const manufacturers = await generateManufacturers(province, city, district)

    await supabase
      .from('query_records')
      .update({
        status: 'completed',
        shipping_address: shippingAddress,
        province,
        city,
        district,
        result: {manufacturers_count: manufacturers.length}
      })
      .eq('id', query_id)

    for (const mfr of manufacturers) {
      await supabase.from('manufacturers').insert({
        query_id,
        name: mfr.name,
        address: mfr.address,
        confidence_score: mfr.confidence_score,
        reasoning: mfr.reasoning,
        risk_flags: mfr.risk_flags,
        business_scope: mfr.business_scope
      })
    }

    return new Response(JSON.stringify({success: true, query_id}), {
      status: 200,
      headers: {...corsHeaders, 'Content-Type': 'application/json'}
    })
  } catch (error) {
    console.error('溯源失败:', error)

    return new Response(JSON.stringify({success: false, error: error.message}), {
      status: 500,
      headers: {...corsHeaders, 'Content-Type': 'application/json'}
    })
  }
})

async function parseProductLink(link: string) {
  await new Promise((resolve) => setTimeout(resolve, 500))

  return {
    shipping_address: '浙江省杭州市萧山区',
    province: '浙江省',
    city: '杭州市',
    district: '萧山区'
  }
}

async function performOCR(imageUrl: string) {
  await new Promise((resolve) => setTimeout(resolve, 500))

  return {
    address: '广东省深圳市龙华区',
    province: '广东省',
    city: '深圳市',
    district: '龙华区'
  }
}

function parseAddress(address: string) {
  const provinceMatch = address.match(/(.*?省)/)
  const cityMatch = address.match(/省?(.*?市)/)
  const districtMatch = address.match(/市?(.*?[区县])/)

  return {
    province: provinceMatch ? provinceMatch[1] : '',
    city: cityMatch ? cityMatch[1] : '',
    district: districtMatch ? districtMatch[1] : ''
  }
}

async function generateManufacturers(province: string, city: string, district: string) {
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const manufacturers = [
    {
      name: `${city}优质制造有限公司`,
      address: `${province}${city}${district}工业园区`,
      confidence_score: 85,
      reasoning: `该企业位于${district}，与发货地高度吻合。经营范围包含相关产品制造，企业规模较大，历史记录良好。`,
      risk_flags: null,
      business_scope: '服装制造、纺织品加工、进出口贸易'
    },
    {
      name: `${city}精工实业股份有限公司`,
      address: `${province}${city}${district}经济开发区`,
      confidence_score: 72,
      reasoning: `该企业在${city}有多个生产基地，产业链完整。与发货地距离较近，可能为实际生产厂家。`,
      risk_flags: null,
      business_scope: '电子产品制造、五金加工、塑料制品'
    },
    {
      name: `${province}品质供应链管理有限公司`,
      address: `${province}${city}市中心商务区`,
      confidence_score: 58,
      reasoning: `该企业为供应链管理公司，可能为中间商。地理位置与发货地有一定距离。`,
      risk_flags: {warning: '非生产型企业，可能为贸易中间商'},
      business_scope: '供应链管理、商品批发、仓储服务'
    }
  ]

  return manufacturers
}
