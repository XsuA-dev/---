import {createClient} from 'jsr:@supabase/supabase-js@2'
import {Aes} from 'npm:wechatpay-axios-plugin@0.9.4'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

const MCH_API_V3_KEY = Deno.env.get('WECHAT_PAY_MCH_API_V3_KEY') || ''

async function decryptPaymentData(
  associatedData: string,
  nonce: string,
  ciphertext: string
): Promise<{outTradeNo: string; transactionId: string}> {
  const plaintext = await Aes.AesGcm.decrypt(ciphertext, MCH_API_V3_KEY, nonce, associatedData)
  const obj = JSON.parse(plaintext)
  return {
    outTradeNo: obj.out_trade_no ?? '',
    transactionId: obj.transaction_id ?? ''
  }
}

Deno.serve(async (req) => {
  try {
    const body = await req.json()

    if (body.event_type !== 'TRANSACTION.SUCCESS') {
      return new Response(JSON.stringify({code: 'SUCCESS', message: '非支付成功事件'}), {
        status: 200,
        headers: {'Content-Type': 'application/json'}
      })
    }

    const {resource} = body
    const {associated_data, nonce, ciphertext} = resource

    const {outTradeNo, transactionId} = await decryptPaymentData(associated_data, nonce, ciphertext)

    const {data: order, error: orderError} = await supabase
      .from('payment_orders')
      .select('*')
      .eq('order_no', outTradeNo)
      .single()

    if (orderError || !order) {
      console.error('订单不存在:', outTradeNo)
      return new Response(JSON.stringify({code: 'FAIL', message: '订单不存在'}), {
        status: 200,
        headers: {'Content-Type': 'application/json'}
      })
    }

    if (order.status === 'paid') {
      return new Response(JSON.stringify({code: 'SUCCESS', message: '订单已处理'}), {
        status: 200,
        headers: {'Content-Type': 'application/json'}
      })
    }

    const {error: updateError} = await supabase
      .from('payment_orders')
      .update({
        status: 'paid',
        wechat_transaction_id: transactionId,
        paid_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('order_no', outTradeNo)

    if (updateError) {
      console.error('更新订单失败:', updateError)
      return new Response(JSON.stringify({code: 'FAIL', message: '更新订单失败'}), {
        status: 200,
        headers: {'Content-Type': 'application/json'}
      })
    }

    if (order.order_type === 'subscription' && order.subscription_type) {
      const {data: currentSub} = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', order.user_id)
        .eq('status', 'active')
        .single()

      const now = new Date()
      const startDate = currentSub && new Date(currentSub.end_date) > now ? new Date(currentSub.end_date) : now
      const endDate = new Date(startDate.getTime() + order.subscription_duration_days * 24 * 60 * 60 * 1000)

      if (currentSub) {
        await supabase.from('subscriptions').update({status: 'expired'}).eq('id', currentSub.id)
      }

      const dailyQuota =
        order.subscription_type === 'personal' ? 20 : order.subscription_type === 'professional' ? 100 : 500

      await supabase.from('subscriptions').insert({
        user_id: order.user_id,
        subscription_type: order.subscription_type,
        status: 'active',
        daily_quota: dailyQuota,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString()
      })
    }

    return new Response(JSON.stringify({code: 'SUCCESS', message: '处理成功'}), {
      status: 200,
      headers: {'Content-Type': 'application/json'}
    })
  } catch (error) {
    console.error('支付回调处理失败:', error)
    return new Response(JSON.stringify({code: 'FAIL', message: error.message}), {
      status: 200,
      headers: {'Content-Type': 'application/json'}
    })
  }
})
