const APP_ID = Deno.env.get('THIRD_PARTY_LOGIN_APP_ID') || ''
const AUTHORIZATION = Deno.env.get('WX_OPEN_CFC_JWT_TOKEN') || ''
const URL = 'https://ct6gb7rg8n0rf.cfc-execute.bj.baidubce.com/get_openid'

Deno.serve(async (req: Request) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
  }

  if (req.method === 'OPTIONS') {
    return new Response('ok', {headers: corsHeaders})
  }

  try {
    const {code} = await req.json()

    if (!code) {
      return new Response(JSON.stringify({success: false, error: '缺少code参数'}), {
        status: 400,
        headers: {...corsHeaders, 'Content-Type': 'application/json'}
      })
    }

    const res = await fetch(URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: AUTHORIZATION
      },
      body: JSON.stringify({
        appid: APP_ID,
        jscode: code
      })
    })

    const data = await res.json()

    if (!data.openid) {
      console.error(`[WeChatLogin FAILED] response=${JSON.stringify(data)}`)
      return new Response(JSON.stringify({success: false, error: '获取openid失败'}), {
        status: 500,
        headers: {...corsHeaders, 'Content-Type': 'application/json'}
      })
    }

    return new Response(JSON.stringify({success: true, openid: data.openid}), {
      status: 200,
      headers: {...corsHeaders, 'Content-Type': 'application/json'}
    })
  } catch (error) {
    console.error('[WeChatLogin ERROR]', error)
    return new Response(JSON.stringify({success: false, error: error.message}), {
      status: 500,
      headers: {...corsHeaders, 'Content-Type': 'application/json'}
    })
  }
})
