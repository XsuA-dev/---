import {createClient} from 'jsr:@supabase/supabase-js@2'
import Wechatpay from 'npm:wechatpay-axios-plugin@0.9.4'
import ShortUniqueId from 'npm:short-unique-id'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

const MERCHANT_ID = Deno.env.get('WECHAT_PAY_MERCHANT_ID') || ''
const MCH_CERT_SERIAL_NO = Deno.env.get('WECHAT_PAY_MCH_CERT_SERIAL_NO') || ''
const MCH_PRIVATE_KEY = Deno.env.get('WECHAT_PAY_MCH_PRIVATE_KEY') || ''
const WECHAT_PAY_PUBLIC_KEY_ID = Deno.env.get('WECHAT_PAY_PUBLIC_KEY_ID') || ''
const WECHAT_PAY_PUBLIC_KEY = Deno.env.get('WECHAT_PAY_PUBLIC_KEY') || ''
const WECHAT_MINIPROGRAM_APPID = Deno.env.get('WECHAT_MINIPROGRAM_LOGIN_APP_ID') || ''

const generateOrderNo = () =>
  `ORD-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${new ShortUniqueId({length: 8}).rnd()}`

Deno.serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
  }

  if (req.method === 'OPTIONS') {
    return new Response('ok', {headers: corsHeaders})
  }

  try {
    const {user_id, openid, order_type, product_name, amount, subscription_type, subscription_duration_days} =
      await req.json()

    if (!user_id || !openid || !order_type || !product_name || !amount) {
      return new Response(JSON.stringify({success: false, error: '缺少必要参数'}), {
        status: 400,
        headers: {...corsHeaders, 'Content-Type': 'application/json'}
      })
    }

    const orderNo = generateOrderNo()

    const {data: order, error: orderError} = await supabase
      .from('payment_orders')
      .insert({
        order_no: orderNo,
        user_id,
        openid,
        order_type,
        product_name,
        amount,
        status: 'pending',
        subscription_type: subscription_type || null,
        subscription_duration_days: subscription_duration_days || null
      })
      .select()
      .single()

    if (orderError) {
      console.error('创建订单失败:', orderError)
      return new Response(JSON.stringify({success: false, error: '创建订单失败'}), {
        status: 500,
        headers: {...corsHeaders, 'Content-Type': 'application/json'}
      })
    }

    const wxpay = new Wechatpay({
      mchid: MERCHANT_ID,
      serial: MCH_CERT_SERIAL_NO,
      privateKey: MCH_PRIVATE_KEY,
      certs: {[WECHAT_PAY_PUBLIC_KEY_ID]: WECHAT_PAY_PUBLIC_KEY}
    })

    const notifyUrl = `${SUPABASE_URL}/functions/v1/wechat_payment_callback`

    const {data: paymentData} = await wxpay.v3.pay.transactions.jsapi.post({
      appid: WECHAT_MINIPROGRAM_APPID,
      mchid: MERCHANT_ID,
      description: product_name,
      out_trade_no: orderNo,
      notify_url: notifyUrl,
      amount: {
        total: Math.round(amount * 100),
        currency: 'CNY'
      },
      payer: {
        openid
      }
    })

    const paymentParams = {
      timeStamp: String(Math.floor(Date.now() / 1000)),
      nonceStr: new ShortUniqueId({length: 32}).rnd(),
      package: `prepay_id=${paymentData.prepay_id}`,
      signType: 'RSA',
      paySign: ''
    }

    const message = `${WECHAT_MINIPROGRAM_APPID}\n${paymentParams.timeStamp}\n${paymentParams.nonceStr}\n${paymentParams.package}\n`
    const sign = await crypto.subtle.sign(
      'RSASSA-PKCS1-v1_5',
      await crypto.subtle.importKey(
        'pkcs8',
        new TextEncoder().encode(MCH_PRIVATE_KEY),
        {name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256'},
        false,
        ['sign']
      ),
      new TextEncoder().encode(message)
    )

    paymentParams.paySign = btoa(String.fromCharCode(...new Uint8Array(sign)))

    return new Response(
      JSON.stringify({
        success: true,
        order_id: order.id,
        order_no: orderNo,
        payment_params: paymentParams
      }),
      {
        status: 200,
        headers: {...corsHeaders, 'Content-Type': 'application/json'}
      }
    )
  } catch (error) {
    console.error('创建支付失败:', error)
    return new Response(JSON.stringify({success: false, error: error.message}), {
      status: 500,
      headers: {...corsHeaders, 'Content-Type': 'application/json'}
    })
  }
})
