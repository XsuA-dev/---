-- 创建用户角色枚举
CREATE TYPE user_role AS ENUM ('user', 'admin');

-- 创建订阅类型枚举
CREATE TYPE subscription_type AS ENUM ('free', 'personal', 'professional', 'enterprise');

-- 创建订阅状态枚举
CREATE TYPE subscription_status AS ENUM ('active', 'expired', 'cancelled');

-- 创建查询状态枚举
CREATE TYPE query_status AS ENUM ('pending', 'processing', 'completed', 'failed');

-- 创建申诉状态枚举
CREATE TYPE appeal_status AS ENUM ('pending', 'approved', 'rejected');

-- 创建用户配置表
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text,
  email text,
  phone text,
  role user_role DEFAULT 'user',
  openid text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建订阅表
CREATE TABLE subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  subscription_type subscription_type NOT NULL DEFAULT 'free',
  status subscription_status NOT NULL DEFAULT 'active',
  start_date timestamptz NOT NULL DEFAULT now(),
  end_date timestamptz,
  daily_quota int NOT NULL DEFAULT 3,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建每日查询次数记录表
CREATE TABLE daily_quotas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  used_count int NOT NULL DEFAULT 0,
  quota_limit int NOT NULL DEFAULT 3,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

-- 创建溯源查询记录表
CREATE TABLE query_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  input_method text NOT NULL,
  input_data jsonb NOT NULL,
  shipping_address text,
  province text,
  city text,
  district text,
  status query_status NOT NULL DEFAULT 'pending',
  result jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建生产厂家信息表
CREATE TABLE manufacturers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  query_id uuid NOT NULL REFERENCES query_records(id) ON DELETE CASCADE,
  name text NOT NULL,
  address text,
  confidence_score numeric(5,2),
  reasoning text,
  risk_flags jsonb,
  business_scope text,
  created_at timestamptz DEFAULT now()
);

-- 创建申诉表
CREATE TABLE appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  query_id uuid NOT NULL REFERENCES query_records(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reason text NOT NULL,
  evidence_files jsonb,
  status appeal_status NOT NULL DEFAULT 'pending',
  admin_response text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_daily_quotas_user_date ON daily_quotas(user_id, date);
CREATE INDEX idx_query_records_user_id ON query_records(user_id);
CREATE INDEX idx_query_records_created_at ON query_records(created_at DESC);
CREATE INDEX idx_manufacturers_query_id ON manufacturers(query_id);
CREATE INDEX idx_appeals_user_id ON appeals(user_id);
CREATE INDEX idx_appeals_status ON appeals(status);

-- 创建触发器函数：自动同步用户到profiles表
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  extracted_username text;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- 从email中提取username（如果是@miaoda.com格式）
  IF NEW.email LIKE '%@miaoda.com' THEN
    extracted_username := split_part(NEW.email, '@', 1);
  ELSE
    extracted_username := NULL;
  END IF;
  
  -- 插入profile
  INSERT INTO public.profiles (id, username, email, phone, role, openid)
  VALUES (
    NEW.id,
    extracted_username,
    CASE WHEN NEW.email NOT LIKE '%@miaoda.com' AND NEW.email NOT LIKE '%@wechat.login' THEN NEW.email ELSE NULL END,
    NEW.phone,
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END,
    COALESCE((NEW.raw_user_meta_data->>'openid')::text, NULL)
  );
  
  -- 创建默认免费订阅
  INSERT INTO public.subscriptions (user_id, subscription_type, status, daily_quota)
  VALUES (NEW.id, 'free', 'active', 3);
  
  RETURN NEW;
END;
$$;

-- 创建触发器
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- 创建辅助函数：检查是否为管理员
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- 设置RLS策略
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_quotas ENABLE ROW LEVEL SECURITY;
ALTER TABLE query_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE manufacturers ENABLE ROW LEVEL SECURITY;
ALTER TABLE appeals ENABLE ROW LEVEL SECURITY;

-- Profiles策略
CREATE POLICY "管理员可以查看所有用户" ON profiles
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以查看自己的资料" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "用户可以更新自己的资料" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- Subscriptions策略
CREATE POLICY "用户可以查看自己的订阅" ON subscriptions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "管理员可以管理所有订阅" ON subscriptions
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Daily quotas策略
CREATE POLICY "用户可以查看自己的配额" ON daily_quotas
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以插入自己的配额记录" ON daily_quotas
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以更新自己的配额" ON daily_quotas
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- Query records策略
CREATE POLICY "用户可以查看自己的查询记录" ON query_records
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以插入自己的查询记录" ON query_records
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "管理员可以查看所有查询记录" ON query_records
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

-- Manufacturers策略
CREATE POLICY "用户可以查看自己查询的厂家信息" ON manufacturers
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM query_records qr
      WHERE qr.id = manufacturers.query_id AND qr.user_id = auth.uid()
    )
  );

CREATE POLICY "管理员可以查看所有厂家信息" ON manufacturers
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

-- Appeals策略
CREATE POLICY "用户可以查看自己的申诉" ON appeals
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "用户可以创建申诉" ON appeals
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "管理员可以管理所有申诉" ON appeals
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 创建Storage buckets
INSERT INTO storage.buckets (id, name, public) 
VALUES 
  ('app-b6f7c8y63ym9_waybill_images', 'app-b6f7c8y63ym9_waybill_images', true),
  ('app-b6f7c8y63ym9_appeal_documents', 'app-b6f7c8y63ym9_appeal_documents', true);

-- Storage策略：面单图片
CREATE POLICY "用户可以上传面单图片" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'app-b6f7c8y63ym9_waybill_images');

CREATE POLICY "用户可以查看面单图片" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'app-b6f7c8y63ym9_waybill_images');

-- Storage策略：申诉文件
CREATE POLICY "用户可以上传申诉文件" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'app-b6f7c8y63ym9_appeal_documents');

CREATE POLICY "用户可以查看申诉文件" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'app-b6f7c8y63ym9_appeal_documents');