-- 创建订单状态枚举
CREATE TYPE order_status AS ENUM ('pending', 'paid', 'cancelled');

-- 创建订单类型枚举
CREATE TYPE order_type AS ENUM ('subscription', 'single_query');

-- 创建支付订单表
CREATE TABLE payment_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_no TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id),
  openid TEXT NOT NULL,
  order_type order_type NOT NULL,
  product_name TEXT NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  status order_status DEFAULT 'pending',
  subscription_type subscription_type,
  subscription_duration_days INT,
  wechat_transaction_id TEXT,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建索引
CREATE INDEX idx_payment_orders_user_id ON payment_orders(user_id);
CREATE INDEX idx_payment_orders_order_no ON payment_orders(order_no);
CREATE INDEX idx_payment_orders_status ON payment_orders(status);

-- RLS策略
ALTER TABLE payment_orders ENABLE ROW LEVEL SECURITY;

-- 用户可以查看自己的订单
CREATE POLICY "Users can view their own orders" ON payment_orders
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- 用户可以创建自己的订单
CREATE POLICY "Users can create their own orders" ON payment_orders
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- 管理员可以查看所有订单
CREATE POLICY "Admins can view all orders" ON payment_orders
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

-- 添加订单号生成函数
CREATE OR REPLACE FUNCTION generate_order_no()
RETURNS TEXT AS $$
DECLARE
  order_no TEXT;
BEGIN
  order_no := 'ORD-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(FLOOR(RANDOM() * 100000000)::TEXT, 8, '0');
  RETURN order_no;
END;
$$ LANGUAGE plpgsql;