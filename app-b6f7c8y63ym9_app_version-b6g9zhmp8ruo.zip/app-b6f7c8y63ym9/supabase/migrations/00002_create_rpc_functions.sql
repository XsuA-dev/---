-- 创建RPC函数：增加配额使用
CREATE OR REPLACE FUNCTION increment_quota_usage(p_user_id uuid, p_date date)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO daily_quotas (user_id, date, used_count, quota_limit)
  VALUES (p_user_id, p_date, 1, 3)
  ON CONFLICT (user_id, date)
  DO UPDATE SET used_count = daily_quotas.used_count + 1;
END;
$$;